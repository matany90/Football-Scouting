package gui.Listeners;

public interface ClosePlayerDialogListener {
public void onCloseDialog();
public void onOpenDialog();
}
