package gui.Listeners;

public interface PlayerTableListener {
	public void rowDeleted(int row);
}
