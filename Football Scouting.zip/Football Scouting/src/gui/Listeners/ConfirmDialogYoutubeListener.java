package gui.Listeners;

public interface ConfirmDialogYoutubeListener {
public void onConfirmClicked();
}
