package gui.Listeners;

import model.Player;

public interface PlayerDetailsListener {
	public void showPlayerDetails(Player player);
}
