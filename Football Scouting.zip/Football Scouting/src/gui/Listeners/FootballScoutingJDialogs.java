package gui.Listeners;

public interface FootballScoutingJDialogs {
	public void layoutComponentsInJDialog();
}
