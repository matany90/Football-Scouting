package gui.Listeners;

public interface LoginDialogListener {
	public boolean LoginDialogChange(String user, String password);

}
